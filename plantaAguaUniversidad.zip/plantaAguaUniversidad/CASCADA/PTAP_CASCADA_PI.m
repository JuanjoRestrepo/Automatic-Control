clc; clear all; close all
format long
syms s K_p K_i K_d

K = 0.4;
T1 = 120; %seg
T2 = 160; %seg
Td = 5*60; %seg (5in)
corriente = 0.02; %A


%Mp = 0.1;
Mp = 0.02;
Ts = 1536;
zetta = (sqrt((log(Mp))^2/(pi^2 + (log(Mp))^2)));
Wn = (4/(zetta*Ts));
sigma1 = 20/Ts;
sigma2 = 20/Ts;

amp = 5760;


s4 = 1;
s3 = (sigma1 + sigma2 + 2*zetta*Wn);
s2 = (sigma1*sigma2 + 2*zetta*Wn*(sigma1+sigma2 ) + Wn^2);
s1 = (2*zetta*Wn*sigma1*sigma2 + (sigma1 + sigma2)*Wn^2);
s0 = Wn^2*sigma1*sigma2;

s_deseada = s4*s^4 + s3*s^3 + s2*s^2 + s1*s + s0;

s_fraccion = vpa(s_deseada,4);

Kd = double(vpa(solve(17/57600+K_d/amp == s2,K_d),7));
Kp = double(vpa(solve(1/1152000+K_p/amp == s1,K_p),7));
Ki = double(vpa(solve(K_i/amp == s0,K_i),7));

