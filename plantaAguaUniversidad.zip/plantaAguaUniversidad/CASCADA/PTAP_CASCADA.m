clc; clear all; close all
format long
syms KP KI  KD s
Kp = 1/300;
Ki = 1.017e-3;
ganancia = 0.4;

%% Control secundario 

P1 = tf(500, [10 1])   % Función de transferencia válvula 
PI = pid(Kp, Ki, 0)    % Control PI diseñado para la válvula
G_LA_2 = minreal(PI*P1) % Multiplicacióin de PI * P1 o planta en lazo abierto
G_LC_2 = minreal(G_LA_2/(1 + G_LA_2)) % Lazo cerrado de la planta secundaria
%% Control primario 
% Una vez se tiene el control secundario, se procede a calcular el control primario
% Teniendo en cuenta lo anterior como un todo, es decir, como P1
retraso = (tf([-60 1] ,[60 1]))
P2 = minreal(tf(0.4,[19200 280 1])) % Función de transferencia del tanque
P = minreal(G_LC_2*P2*retraso)  % Planta en lazo abierto P1*P2 tanque * válvula controlada
% Ya que la función de transferencia es de 4 orden en lazo abierto y dado
% que si implementamos un control PI o PID se aumentará a quinto orden,
% miramos entoncs cuáles son los polos dominantes y remanentes para buscar
% cancelar los que sean posibles. Para ello miramos el LGR:

figure(1)
rlocus(P)

% Como vimos en la función anterior, se tienen 2 polos y un cero que están muy
% alejados del polo dominante, por tanto procedemos a eliminarlos y miramos
% su comportamiento, comparándolo con el original:
nuevo_P = minreal(tf([19.67*1.059e-06], [1 0.0145849 0.0000520769])*retraso)

figure(2)
hold on 
step(P)
step(nuevo_P)
hold off

% Como podemos ver, la función de transferencia nueva es casi idéntica a la
% original, por tanto procedemos a realizar un control PID para esta nueva FT

% El PID resultante es: 
PID_2 = pid(43.6831, 0.2338, 3140.66)

G_LA_1 = PID_2 * nuevo_P
G_LC_1 = G_LA_1 / (1 + G_LA_1)

figure(3)

step(G_LC_1)

%pidTuner(nuevo_P)


